
prism.registerWidget("smartLabel", {
	name : "smartLabel",
	family : "indicator",
	title : "Widget",
	hideNoResults:true,
	iconSmall : "/plugins/CustomWidget/logo.png",
	styleEditorTemplate: "/plugins/CustomWidget/styler.html",
	style: {
		showLabels: true,
		showFirstOnly: false,
		halign: "left",
		size: "12pt"
	},
	options:{
		title:true,
		data: []
	},
	// sizing must be stated
	sizing: {
		minHeight: 50, //header
		maxHeight: 2048,
		minWidth: 128,
		maxWidth: 2048,
		height: 128,
		defaultWidth: 512
	},
	data : {
		selection : [],
		defaultQueryResult : {},
		panels : [
			//dimension panel
			{
				name : 'Value',
				type : 'visible',
				metadata : {
					types : ['measures'],
					maxitems : -1
				}
			},
			{
				name : 'Minimum Goal',
				type : 'visible',
				metadata : {
					types : ['measures'],
					maxitems : -1
				}
			},
			{
				name : 'Performance Goal',
				type : 'visible',
				metadata : {
					types : ['measures'],
					maxitems : -1
				}
			},
			{
				name : 'min progress',
				type : 'visible',
				metadata : {
					types : ['measures'],
					maxitems : -1
				}
			},
			{
				name : 'max progress',
				type : 'visible',
				metadata : {
					types : ['measures'],
					maxitems : -1
				}
			},
			{
				name: 'filters',
				type: 'filters',
				metadata: {
					types: ['measures'],
					maxitems: -1
				}
			}
		],

		allocatePanel : function (widget, metadataItem) {

			if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("Value").items.length < 1) {

				return "Value";
			}
if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("Minimum Goal").items.length < 1) {

				return "Minimum Goal";
			}
if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("Performance Goal").items.length < 1) {

				return "Performance Goal";
			}
if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("min progress").items.length < 1) {

				return "min progress";
			}
if (!prism.$jaql.isMeasure(metadataItem) && widget.metadata.panel("max progresss").items.length < 1) {

				return "max progresss";
			}
		},

		// returns true/ reason why the given item configuration is not/supported by the widget
		isSupported : function (items) {

			return this.rankMetadata(items, null, null) > -1;
		},

		// ranks the compatibility of the given metadata items with the widget
		rankMetadata : function (items, type, subtype) {

			var a = prism.$jaql.analyze(items);

			// require at least 2 dimensions of lat and lng and 1 measur
                      return 0;
		},

		// populates the metadata items to the widget
		populateMetadata : function (widget, items) {

			var a = prism.$jaql.analyze(items);

			// allocating dimensions
			widget.metadata.panel("Value").push(a.measures);
			widget.metadata.panel("Minimum Goal").push(a.measures);
			widget.metadata.panel("Performance Goal").push(a.measures);
			widget.metadata.panel("min progress").push(a.measures);
			widget.metadata.panel("max progress").push(a.measures);
			widget.metadata.panel("filters").push(a.measures);
		},

		// builds a jaql query from the given widget
		buildQuery : function (widget) {

			// building jaql query object from widget metadata
			var query = {
				datasource : widget.datasource,
				metadata : []
			};

			var filters = widget.dashboard.filters.$$items;

			// pushing items
			widget.metadata.panel("Value").items.forEach(function (item) {
				//console.log(item);
				filters.forEach(function(filter) {
					if (filter.isCascading) {
						filter.levels.forEach(function(level) {
							if (level.dim === item.jaql.dim) {
								item.jaql.filter = level.filter;
							}
						});
					}
				});
				query.metadata.push(item);
			});
	widget.metadata.panel("Minimum Goal").items.forEach(function (item) {
				
				filters.forEach(function(filter) {
					if (filter.isCascading) {
						filter.levels.forEach(function(level) {
							if (level.dim === item.jaql.dim) {
								item.jaql.filter = level.filter;
							}
						});
					}
				});
				query.metadata.push(item);
			});

widget.metadata.panel("Performance Goal").items.forEach(function (item) {
				
				filters.forEach(function(filter) {
					if (filter.isCascading) {
						filter.levels.forEach(function(level) {
							if (level.dim === item.jaql.dim) {
								item.jaql.filter = level.filter;
							}
						});
					}
				});
				query.metadata.push(item);
			});

widget.metadata.panel("min progress").items.forEach(function (item) {
				
				filters.forEach(function(filter) {
					if (filter.isCascading) {
						filter.levels.forEach(function(level) {
							if (level.dim === item.jaql.dim) {
								item.jaql.filter = level.filter;
							}
						});
					}
				});
				query.metadata.push(item);
			});

widget.metadata.panel("max progress").items.forEach(function (item) {
				
				filters.forEach(function(filter) {
					if (filter.isCascading) {
						filter.levels.forEach(function(level) {
							if (level.dim === item.jaql.dim) {
								item.jaql.filter = level.filter;
							}
						});
					}
				});
				query.metadata.push(item);
			});

			// series - dimensions
			widget.metadata.panel('filters').items.forEach(function (item) {

				item = $$.object.clone(item, true);
				item.panel = "scope";

				query.metadata.push(item);
			});

			return query;
		},

		// prepares the widget-specific query result from the given result data-table
		processResult : function (widget, queryResult) {

			widget.options.data = [];

			var md = widget.metadata.panels[0].items;
			var md1 = widget.metadata.panels[1].items;
                        var md2 = widget.metadata.panels[2].items;
			var md3 = widget.metadata.panels[3].items;
                        var md4 = widget.metadata.panels[4].items;
			var dataOptions = [];

			// Set categories info
			md.forEach(function(item){
				dataOptions.push({
					labelName: item.jaql.title,
					labelValues: [],
					labelDim: item.jaql.dim
				})
			});
			md1.forEach(function(item){
				dataOptions.push({
					labelName: item.jaql.title,
					labelValues: [],
					labelDim: item.jaql.dim
				})
			});
                        md2.forEach(function(item){
				dataOptions.push({
					labelName: item.jaql.title,
					labelValues: [],
					labelDim: item.jaql.dim
				})
			});
			 md3.forEach(function(item){
				dataOptions.push({
					labelName: item.jaql.title,
					labelValues: [],
					labelDim: item.jaql.dim
				})
			});
			 md4.forEach(function(item){
				dataOptions.push({
					labelName: item.jaql.title,
					labelValues: [],
					labelDim: item.jaql.dim
				})
			});

			// Get labels for each category
			queryResult.rows().forEach(function(row){
//console.log(row);
				row.forEach(function(item,index){
			
					if(dataOptions[index].labelValues.indexOf(item.text) == -1){
						dataOptions[index].labelValues.push(item.text);
					}
				});
			});

			widget.options.data = dataOptions;

			return queryResult;
		}
	},

	render : function (widget, event) {
		console.log(widget.options.data);
		console.log(event);
		//	Get the html element
		var el = $(event.element);

		//	Clear anything old in the html
		el.empty();

		//	Get the data
		var data = widget.options.data;

if(widget.options.data[0].labelName&&widget.options.data[1].labelName&&widget.options.data[2].labelName){

var value=widget.options.data[0].labelName;
var mval=widget.options.data[1].labelName;
var pval=widget.options.data[2].labelName;

//console.log(widget.metadata.panels[0].items[0].format.mask);
var newvalue=value;
var newmval=mval;
var newpval=pval;

if(widget.metadata.panels[0].items[0].format.mask.currency){
//console.log("nithin currency");

newvalue=widget.metadata.panels[0].items[0].format.mask.currency.symbol+""+value;


}

if(widget.metadata.panels[1].items[0].format.mask.currency){
//console.log("nithin currency");

newmval=widget.metadata.panels[1].items[0].format.mask.currency.symbol+""+mval;


}
if(widget.metadata.panels[2].items[0].format.mask.currency){
//console.log("nithin currency");

newpval=widget.metadata.panels[2].items[0].format.mask.currency.symbol+""+pval;


}

if(widget.metadata.panels[0].items[0].format.mask.percent){
newvalue=newvalue+"%";

}
if(widget.metadata.panels[1].items[0].format.mask.percent){
newmval=newmval+"%";

}
if(widget.metadata.panels[2].items[0].format.mask.percent){
newpval=newpval+"%";

}
el.append(`

  


<div class="box largest">
  <!-- Do Not include this outer containter Div -->
<figure>
  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="chart" aria-labelledby="title" role="img" id="chartsvg">
     <title id="title">Goal Chart</title> 
     <svg x="0%" y="8">
        <text x="0" y="16" id="`+widget._id+`" font-family="lato" font-weight="700" font-size="20">
          93.00%
        </text>
    </svg>
    <svg x="33%" y="0">
        <svg x="0" y="0">
            <line class="min-goalline yellow" x1="3" y1="0" x2="3" y2="30" /> 
            <text font-family="roboto" y="10" x="8" font-size="10">
              Minimum
            </text>
            <text id="mvalue`+widget._id+`" font-family="lato" y="26" x="8" font-weight="700" font-size="14">
              33.33%
            </text>
        </svg>
        <svg x="33%" y="0">
          <line class="max-goalline green" x1="3" y1="0" x2="3" y2="30"  />  
          <text font-family="roboto" y="10" x="8" font-size="10">
            Performance
          </text>
          <text font-family="lato" id="pvalue`+widget._id+`" y="26" x="8" font-weight="700" font-size="14">
            93.33%
          </text>
      </svg>
    </svg>
    <svg x="0" y="40">
              <g class="bar">
                <rect y="5" width="100%" height="48"></rect>
              </g>
              <line id="line1`+widget._id+`" class="min-goalline yellow" x1="80%" y1="0" x2="80%" y2="58" />
              <line id="line2`+widget._id+`" class="max-goalline green" x1="90%" y1="0" x2="90%" y2="58" />  
              <g id="pcol`+widget._id+`" class="bar green">
                <rect id="pbar`+widget._id+`" y="5" width="93%" height="48"></rect>
              </g>
    </svg>
  </svg>
  </figure>
  <!-- END WIDGET SVG -->
</div>


`);



//console.log(el.getElementById("value"));
document.getElementById(widget._id).innerHTML=newvalue;
document.getElementById("mvalue"+widget._id).innerHTML=newmval;
document.getElementById("pvalue"+widget._id).innerHTML=newpval;
document.getElementById("pbar"+widget._id).style.width=value+'%';




//console.log("not reached");
document.getElementById("line1"+widget._id).setAttribute("x1",mval+"%");
document.getElementById("line1"+widget._id).setAttribute("x2",mval+"%");
document.getElementById("line2"+widget._id).setAttribute("x1",pval+"%");
document.getElementById("line2"+widget._id).setAttribute("x2",pval+"%");


if(value>mval && value <pval){
document.getElementById("pcol"+widget._id).setAttribute("class","bar yellow");



}

else if(value>=pval){
document.getElementById("pcol"+widget._id).setAttribute("class","bar green");
}


else if (value <= mval) {
document.getElementById("pcol"+widget._id).setAttribute("class","bar red");
}
else{

}
//console.log("new code can be done");
//var minprog=widget.options.data[3].labelName;
//var maxprog=widget.options.data[4].labelName;
/*if(widget.options.data[3].labelName){
console.log(widget.options.data[3].labelName);
}
if(widget.options.data[4].labelName){
console.log(widget.options.data[4].labelName);
}*/

if(widget.options.data[3].labelName && widget.options.data[4].labelName){
//console.log(widget.options.data[3].labelName);
//console.log(widget.options.data[4].labelName);

if(widget.options.data[2].labelName){

var diff=widget.options.data[4].labelName-widget.options.data[3].labelName;
var temp=(widget.options.data[2].labelName/diff);

var temp1=temp*100;

var temp2=(widget.options.data[1].labelName/diff);
var temp3=temp2*100;
//console.log(temp1);
document.getElementById("line1"+widget._id).setAttribute("x1",temp3+"%");
document.getElementById("line1"+widget._id).setAttribute("x2",temp3+"%");
document.getElementById("line2"+widget._id).setAttribute("x1",temp1+"%");
document.getElementById("line2"+widget._id).setAttribute("x2",temp1+"%");
}
//document.getElementById("line2").setAttribute("x1",90+"%");
//document.getElementById("line2").setAttribute("x2",90+"%");


 var tval=(value/diff)*100;
document.getElementById("pbar"+widget._id).style.width=tval+'%';

if(tval>temp3 && value <temp1){
document.getElementById("pcol"+widget._id).setAttribute("class","bar yellow");



}

else if(tval>=temp1){
document.getElementById("pcol"+widget._id).setAttribute("class","bar green");
}


else if (tval<= temp3) {
document.getElementById("pcol"+widget._id).setAttribute("class","bar red");
}
else{

}

}



}

else{

}



	},
    

	destroy : function (s, e) {}
});